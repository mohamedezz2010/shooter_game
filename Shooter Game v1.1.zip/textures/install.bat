pip install pygame
start Game.lnk